# PDF to Audio WebApp

Web application where you can convert your pdf into audio file. 

### Description:
**Frontend:** HTML, CSS and Bootstrap</br>
**Backend:** Python Flask</br>
**Libraries Used:** PyPDF2, gTTS, uuid</br>

### Deployed Link:
Link ➡️ https://pdf-to-audio.mashymali.repl.co/

### Screenshot:
![1](https://user-images.githubusercontent.com/87118384/220422380-ab9ef1a9-3b91-4202-a097-d298f490f803.PNG)
</br>
![2](https://user-images.githubusercontent.com/87118384/220422674-8ed81f24-2e07-4711-a3f8-8df305f2c15f.PNG)
